import arcpy
from arcpy.sa import *
import os

# ----------------------------- Parameters -----------------------------
arcpy.env.workspace = "in_memory"
network_dataset = arcpy.GetParameterAsText(0)
input_destinations = arcpy.GetParameterAsText(1)
interval_points = arcpy.GetParameterAsText(2)
input_barriers = arcpy.GetParameterAsText(3)
cellSize = arcpy.GetParameterAsText(4)
cost_type = arcpy.GetParameterAsText(5)
clipping_geometry = arcpy.GetParameterAsText(6)
output_raster = arcpy.GetParameterAsText(7)

arcpy.env.overwriteOutput = True

### Beginning of the script
try:
    # ----------------------------- A) Discover edges & optional clip -----------------------------

    desc = arcpy.Describe(network_dataset)
    gdb_path = os.path.dirname(desc.catalogPath)  # geobaza albo FDS
    arcpy.env.workspace = gdb_path
    edges_fc = None
    for fc in arcpy.ListFeatureClasses():
        fc_path = os.path.join(gdb_path, fc)
        if arcpy.Describe(fc_path).shapeType == "Polyline":
            arcpy.AddMessage(f"[A] Found layer with edges: {fc_path}")
            edges_fc = fc_path
            break
    if edges_fc is None:
        raise RuntimeError("No Polyline feature class (Edges) found in geodatabase folder.")

    # Switch back to in_memory for temp outputs
    arcpy.env.workspace = "in_memory"

    # Optionally clip edges to the mask
    if clipping_geometry:
        edges = arcpy.analysis.Clip(edges_fc, clipping_geometry, "edges_clip")
    else:
        edges = edges_fc

    # ----------------------------- B) Origin points -----------------------------
    # Create network intersection points (nodes) and optionally densify with points every N meters.
    arcpy.management.Dissolve(edges,
                              "siec_piesza_piasecz_Dissolve", "", "", "SINGLE_PART")
    arcpy.analysis.Intersect([edges], "Streets_Intersect", "", "", "POINT")
    origins = arcpy.management.MultipartToSinglepart("Streets_Intersect", "intersect_points_single")
    arcpy.management.DeleteIdentical(origins, ["Shape"])
    arcpy.management.Delete("Streets_Intersect")
    #interval_val = float(interval_points)
    #interval_unit = "meters"
    if interval_points:
        arcpy.AddMessage(f" [B]Generating points every {interval_points} meters")
        points = arcpy.management.GeneratePointsAlongLines(
            edges,
            "Points_along_line",
            "DISTANCE",
            f"{interval_points} meters")
        origins_input = arcpy.management.Merge([origins, points], "origins_merged")
    else:
        origins_input = origins

    # ----------------------------- C) Travel mode & OD matrix -----------------------------
    # Select a travel mode whose impedance units match requested cost type (time vs distance).
    tmodes = arcpy.nax.GetTravelModes(network_dataset)
    desc = arcpy.Describe(network_dataset)
    attrs = {a.name: a for a in (getattr(desc, "networkAttributes", None) or getattr(desc, "attributes", []))}

    time_units = {"Seconds", "Minutes", "Hours"}
    dist_units = {"Meters", "Kilometers", "Feet", "Miles"}


    selected = None
    for tm in tmodes.values():
        attr = attrs.get(tm.impedance)
        if not attr:
            continue
        u = str(getattr(attr, "units", ""))
        if (cost_type == "Time - Fastest Path" and u in time_units) or (cost_type == "Distance - Shortest Path" and u in dist_units):
            selected = (tm, u)
            break

    if not selected:
        raise RuntimeError(f"No travel mode with matching units for requested cost_type: '{cost_type}'")

    tm, units_enum = selected
    odcm = arcpy.nax.OriginDestinationCostMatrix(network_dataset)
    odcm.travelMode = tm

    total_cost_column = f"Total_{tm.impedance}"
    arcpy.AddMessage(f"TM: {tm.name} | imp: {attrs[tm.impedance].units} ")

    # Build OD Cost Matrix
    od_cost_matrix = arcpy.na.MakeODCostMatrixLayer(network_dataset, "test", tm.impedance, "", 1, "", "", "")

    # Add origins & destinations
    origins_layer = arcpy.na.AddLocations(od_cost_matrix, "Origins", origins_input, )
    destinations_layer = arcpy.na.AddLocations(od_cost_matrix, "Destinations", input_destinations)

    # ----------------------------- D) Barrier handling -----------------------------
    # Normalize barriers to polygons:
    # - Polyline: closed rings -> polygon, open lines -> 0.5 m buffer (ALL dissolve)
    polygon_barrier = None
    if input_barriers:
        warstwy_polygon = []
        barrier_list = input_barriers.split(";")

        arcpy.AddMessage(f"[D] Barrier layers provided: {len(barrier_list)}")
        for barrier in barrier_list:
            desc = arcpy.Describe(barrier)
            shape_type = desc.shapeType
            arcpy.AddMessage(f"{barrier} -> {shape_type}")
            if shape_type == "Polyline":
                idx = barrier_list.index(barrier)
                prefix = f"bariera_{idx}"
                zamkniete_poligony = f"{prefix}_zamkniete"
                otwarte_linie = f"{prefix}_otwarte"
                bufor_otwartych = f"{prefix}_bufor"

                # Create temp feature classes to separate closed and open polylines
                arcpy.CreateFeatureclass_management(arcpy.env.workspace, zamkniete_poligony, "POLYGON",
                                                    spatial_reference=barrier)
                arcpy.CreateFeatureclass_management(arcpy.env.workspace, otwarte_linie, "POLYLINE",
                                                    spatial_reference=barrier)

                # Rozdziel linie
                cursor = arcpy.da.SearchCursor(barrier, ["SHAPE@"])
                ic_zamkniete = arcpy.da.InsertCursor(zamkniete_poligony, ["SHAPE@"])
                ic_otwarte = arcpy.da.InsertCursor(otwarte_linie, ["SHAPE@"])
                for row in cursor:
                    shape = row[0]
                    first = shape.firstPoint
                    last = shape.lastPoint
                    if (first.X == last.X) and (first.Y == last.Y):
                        # Closed ring -> convert to polygon
                        array = arcpy.Array(shape.getPart(0))
                        poly = arcpy.Polygon(array, shape.spatialReference)
                        ic_zamkniete.insertRow([poly])
                    else:
                        # Open line -> keep as line for buffering
                        ic_otwarte.insertRow([shape])
                del cursor, ic_zamkniete, ic_otwarte
                # Buffer open lines slightly to act as area barriers
                arcpy.analysis.Buffer(otwarte_linie, bufor_otwartych, "0.5 Meters", dissolve_option="ALL")

                warstwy_polygon.extend([zamkniete_poligony, bufor_otwartych])

            elif shape_type == "Polygon":
                warstwy_polygon.append(barrier)

            else:
                arcpy.AddError("The layer in neither polygon nor polyline")
                raise arcpy.ExecuteError

        if warstwy_polygon:
            polygon_barrier = "polygon_barrier"
            arcpy.FeatureToPolygon_management(warstwy_polygon, polygon_barrier)

            # Remove Destinations and Origins that fall inside barriers
            arcpy.SelectLayerByLocation_management("test\Destinations", "INTERSECT", polygon_barrier, "",
                                                   "NEW_SELECTION")
            arcpy.DeleteFeatures_management("test\Destinations")
            arcpy.SelectLayerByLocation_management("test\Origins", "INTERSECT", polygon_barrier, "", "NEW_SELECTION")
            arcpy.DeleteFeatures_management("test\Origins")
        else:
            arcpy.AddError("[D] No valid barrier polygons produced from inputs.")
            raise arcpy.ExecuteError


    else:
        merged_barriers = None
        arcpy.AddMessage("[D] No barrier layers were specified.")


    # ----------------------------- E) Solve OD Cost Matrix and compute final cost -----------------------------
    arcpy.na.Solve(od_cost_matrix)

    # Adding a new final cost column
    arcpy.management.AddField("test\Lines", "final_cost", "DOUBLE")
    arcpy.management.AddJoin("test\Lines", "DestinationID", "test\Destinations", "ObjectID")

    arcpy.CopyFeatures_management("test\Lines", "layer_with_full_costs")



    fields = [f.name for f in arcpy.ListFields("layer_with_full_costs")]

    total_meters = None
    distance_to_network = None
    originid = None

    # przypisanie p
    for field in fields:
        if "OriginID" in field:
            originid = field
        elif f"{total_cost_column}" in field:
            total_meters = field
        elif "DistanceToNetworkInMeters" in field:
            distance_to_network = field

    if not total_meters or not distance_to_network:
        raise ValueError("Could not find required fields in the layer")

    # If cost is time, convert meters out of the network to required time's unit
    if cost_type == "Time - Fastest Path":
        # Walking speed in m/s
        SPEED_M_PER_S = 1.4
        Unit_factors = {
            "Seconds": 1.0 / SPEED_M_PER_S,  # m / (m/s) = seconds
            "Minutes": 1.0 / SPEED_M_PER_S / 60.0,  # convert to minutes
            "Hours": 1.0 / SPEED_M_PER_S / 3600.0
        }
        if units_enum not in Unit_factors:
            raise RuntimeError(f"Unsupported time unit: {units_enum}")
        factor = Unit_factors[units_enum]

        # Calculate out of the network distance converted to time
        arcpy.CalculateField_management("layer_with_full_costs", distance_to_network, f"!{distance_to_network}! * {factor}", "PYTHON3")
    else:
        arcpy.AddMessage("Using distance cost")
    expression = f"!{total_meters}! + !{distance_to_network}!"

    try:
        arcpy.management.CalculateField("layer_with_full_costs", "final_cost", expression, "PYTHON3")
    except Exception as e:
        arcpy.AddWarning(f"CalculateField for the final cost failed: {e}")

    # Ensure we end up with a DOUBLE
    field_type = [f.type for f in arcpy.ListFields("layer_with_full_costs") if f.name == "final_cost"]
    if field_type[0] == "String":
        arcpy.management.AddField("layer_with_full_costs", "full_cost_double", "DOUBLE")
        arcpy.management.CalculateField("layer_with_full_costs", "full_cost_double",
                                            'float(!final_cost!.replace(",", "."))', "PYTHON3")
        arcpy.management.DeleteField("layer_with_full_costs", "final_cost")
        full_cost = "full_cost_double"

    else:
        full_cost = "final_cost"

    # ----------------------------- F) Join cost to Origins and ensure metric coordinate system -----------------------------

    arcpy.AddMessage("[F] Joining final cost back to Origins and ensuring metric coordinate system for the interpolation.")
    origins_ref = arcpy.Describe("test\Origins").spatialReference
    if origins_ref.type == "Geographic":
        arcpy.management.Project("test\Origins", "origins_metric", arcpy.SpatialReference(54034))
        origins_metric = "origins_metric"
    else:
        origins_metric = "test\Origins"

    arcpy.management.AddJoin(origins_metric, "ObjectID", "layer_with_full_costs", f"{originid}")


    # ----------------------------- G) Interpolate with Spline With Barriers -----------------------------
    arcpy.AddMessage("[G] Running Spline With Barriers.")
    if polygon_barrier and arcpy.Exists(polygon_barrier):
        raster= SplineWithBarriers(origins_metric, full_cost, polygon_barrier, cellSize)

    else:
        raster = SplineWithBarriers(origins_metric, full_cost, "", cellSize)

    # ----------------------------- H) Deleting negative values, optional clip -----------------------------
    if arcpy.Exists(output_raster):
        arcpy.Delete_management(output_raster)
    raster_check = Raster(raster)
    min_value = raster_check.minimum
    if min_value < 0:
        arcpy.AddMessage("Negative values detected, applying smoothing")

        raster_null = SetNull(raster_check < 0, raster_check)

        # Limit smoothing to valid data only
        valid_data_mask = Con(IsNull(raster_check) == 0, 1)
        arcpy.env.mask = valid_data_mask

        raster_popr = FocalStatistics(raster_null, NbrRectangle(10, 10, "CELL"), "MEAN", "DATA")

        # Reset mask
        arcpy.env.mask = None

        # Optional clip to the area of interests
        if clipping_geometry:
            clip_extent = arcpy.Describe(clipping_geometry).extent
            extent_str = f"{clip_extent.XMin} {clip_extent.YMin} {clip_extent.XMax} {clip_extent.YMax}"
            clip = arcpy.management.Clip(raster_popr, extent_str, "raster_clip", clipping_geometry, "",
                                         "ClippingGeometry", "NO_MAINTAIN_EXTENT")
            raster_clip = Raster(clip.getOutput(0))
            arcpy.management.CopyRaster(raster_clip, output_raster, format="TIFF")
        else:
            arcpy.management.CopyRaster(raster, output_raster, format="TIFF")

    else:
        arcpy.AddMessage("[H] No negatives -> saving raster")

        if clipping_geometry:
            clip_extent = arcpy.Describe(clipping_geometry).extent
            extent_str = f"{clip_extent.XMin} {clip_extent.YMin} {clip_extent.XMax} {clip_extent.YMax}"
            clip = arcpy.management.Clip(raster, extent_str, "raster_clip", clipping_geometry, "",
                                         "ClippingGeometry", "NO_MAINTAIN_EXTENT")
            raster_clip = Raster(clip.getOutput(0))
            raster_clip.save(output_raster)
        else:
            raster.save(output_raster)

    arcpy.AddMessage("Interpolation finished successfully.")

except Exception as e:
    arcpy.AddError("An unexpected error occurred.")
    arcpy.AddMessage(str(e))

arcpy.AddMessage("Processing finished.")

